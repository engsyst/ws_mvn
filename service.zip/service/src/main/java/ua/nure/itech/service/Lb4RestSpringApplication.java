package ua.nure.itech.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lb4RestSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(Lb4RestSpringApplication.class, args);
	}

}
