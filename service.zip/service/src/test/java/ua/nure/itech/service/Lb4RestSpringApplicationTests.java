package ua.nure.itech.service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Lb4RestSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
